package com.impl;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.controller.UserController;
import com.domain.User;

import java.util.Collection;
import java.util.Collections;

@Component
public class UserDetailsServiceImpl implements UserDetailsService
{
    @SuppressWarnings("unchecked")
	@Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException
    {
    	Boolean flag = false;
    	User user = new User();
    	for (User u : UserController.userList) {
    		if(u.getUserName().equals(username)) {
    			flag = true;
    			user = u;
    		}
    	}
        if(!flag)
        {
            throw new UsernameNotFoundException(username);
        }
        return new org.springframework.security.core.userdetails.User(user.getUserName(), user.getPassword(), (Collection<? extends GrantedAuthority>) Collections.emptyList());
    }
}