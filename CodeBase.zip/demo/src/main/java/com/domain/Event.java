package com.domain;

public class Event {
	
	private Boolean isFuelLidOpen;
	
	private String city;

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Event(Boolean isFuelLidOpen, String city) {
		super();
		this.isFuelLidOpen = isFuelLidOpen;
		this.city = city;
	}

	public Boolean getIsFuelLidOpen() {
		return isFuelLidOpen;
	}

	public void setIsFuelLidOpen(Boolean isFuelLidOpen) {
		this.isFuelLidOpen = isFuelLidOpen;
	}
	
	public Event (){}

	@Override
	public String toString() {
		return "Event [isFuelLidOpen=" + isFuelLidOpen + ", city=" + city + "]";
	}
	
	

}
