package com.service;

import java.util.Random;

import com.domain.Event;

public class RandomEventGeneration {

	 public static Event generateRandomEvent() 
	    { 
	        String[] arr={"Bangalore", "Pune", "Mumbai", "Kolkata", "Bhopal","Hyderabad"}; 
	        Random r=new Random(); 
	        int randomNumber=r.nextInt(arr.length);
	        Event event = new Event();
	        event.setCity(arr[randomNumber]);
	        event.setIsFuelLidOpen(true);
	        return event;
	    } 
	
	
}
