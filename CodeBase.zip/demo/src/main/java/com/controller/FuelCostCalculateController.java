package com.controller;

import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.*;

@RestController
@RequestMapping ("/fuel/v1")
public class FuelCostCalculateController {
	
	static HashMap<String,BigDecimal> fuelCostList = new HashMap<>();
	static {
		
		fuelCostList.put("Bangalore", new BigDecimal(95));
		fuelCostList.put("Pune", new BigDecimal(86.7));
		fuelCostList.put("Mumbai", new BigDecimal(89.5));
		fuelCostList.put("Kolkata", new BigDecimal(97.5));
		fuelCostList.put("Bhopal", new BigDecimal(91.6));
		fuelCostList.put("Hyderabad", new BigDecimal(90.8));
		
	}
	
	@GetMapping("/getfuelcost/{city}")
	public BigDecimal getFuelCost (@PathVariable String city) throws Exception {
		
		if(city == null || city.length()==0) {
			throw new Exception("Invalid city name !!");
		}
		
		if(fuelCostList.containsKey(city)) {
			
			//Assuming car has 50l tank capacity
			BigDecimal costPerLitre = fuelCostList.get(city);
			return costPerLitre;
			
		}else throw new Exception("Data not present");
		
	}
	


}
