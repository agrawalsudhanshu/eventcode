package com.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import com.domain.Event;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

@RestController
@RequestMapping ("/eventreceiving/v1")
public class EventReceivingController {
	
	static HashMap<String,BigDecimal> cacheMap = new HashMap<>();
	static BigDecimal carCapacity = new BigDecimal(50);
	static LocalDate cacheDate = null;
	
	@Value("${fuelCostURL}")
	private String fuelCostURL;
	
	@PostMapping("/captureevent")
	public BigDecimal captureEvent (@RequestBody Event event) throws Exception {
		
		//if(event == null) throw new Exception ("Invalid event");
		
		if(event == null) throw new Exception ("Invalid event");
		
		if(event.getCity() == null) throw new Exception ("Please provide city name !!");
		
		if(cacheDate == null) cacheDate = LocalDate.now();
		
		if(cacheDate.isBefore(LocalDate.now())) {
			cacheMap.clear();
			cacheDate = LocalDate.now();
		}
		
		if(cacheMap.containsKey(event.getCity()))return cacheMap.get(event.getCity());
		
		BigDecimal costPerLitre = new BigDecimal(0);
		
		if(event.getIsFuelLidOpen()) {
			RestTemplate restTemplate = new RestTemplate();
			ResponseEntity<BigDecimal> response = restTemplate.getForEntity(fuelCostURL + event.getCity(), BigDecimal.class); 
			costPerLitre = response.getBody();
			cacheMap.put(event.getCity(), costPerLitre);
			
		}
		return costPerLitre;
		
	}
	


}
