package com.controller;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import com.domain.Event;
import com.service.RandomEventGeneration;

@RestController
@RequestMapping ("/event/v1")
public class EventController {
	
	@Value("${schedulerURL}")
	private String schedulerURL;
	
	@Value("${manualURL}")
	private String manualURL;
	
	@GetMapping("/getevent")
	public ResponseEntity <String> constantPush () {
		//Api which will be called by scheduler every 2 mins
		try {
		HttpEntity<Event> request = new HttpEntity<>(RandomEventGeneration.generateRandomEvent());
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<BigDecimal> response = restTemplate
		  .exchange(schedulerURL, HttpMethod.POST, request, BigDecimal.class);
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(request.getBody() + ", Fuel Cost Calculated -> "+response.getBody().toString());
		}catch(Exception e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		}
		
		
	}
	
	@PostMapping("/updatepush")
	public ResponseEntity <String> updatePush (@RequestBody Event event) {
		// To be captured by the user in case of manual event
		try {
			HttpEntity<Event> request = new HttpEntity<>(event);
			RestTemplate restTemplate = new RestTemplate();
			ResponseEntity<BigDecimal> response = restTemplate
			  .exchange(manualURL, HttpMethod.POST, request, BigDecimal.class);		 
			return ResponseEntity.status(HttpStatus.ACCEPTED).body(request.getBody() + ", Fuel Cost Calculated -> "+response.getBody().toString());
		}catch(Exception e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		}
		
	}
	

}
